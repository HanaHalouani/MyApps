﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    public class Program
    {
        public static string MakeItAString(List<int> myList)
        {
            string theStringList = "";
            foreach (var VARIABLE in myList)
            {
                char myChar = '"';
                string newString = string.Format("{0}{1}{2},", myChar, VARIABLE, myChar);
                theStringList += newString;
            }

            return theStringList;
        }

        static void Main(string[] args)
        {
            List<int> theIntList = new List<int>()
            {
              5455456,5646856,5464641,48563656,54161,56461,54166,5413651
            };

           string mylastString  = MakeItAString(theIntList);
        }
    }
}
